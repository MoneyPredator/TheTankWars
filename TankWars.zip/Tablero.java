import java.util.Random;
class Tablero{
//-----------------------------------------------------------------------    
  //Metodo para crear el tablero en variable
      public static Tanque[][] board(){
Tanque[][] tab = new Tanque[2][2];
      int tankNum = (int)((Math.random()*4+1));
     
    while(true){
      for(int i=0;i<tankNum;i++){
      int numT = (int)((Math.random()*2));
      if(numT == 1){
        
        if(tab[0][0]==null){
         tab[0][0] = new TanquesNormales(10);
        }
       else if(tab[0][1]==null){
         tab[0][1] = new TanquesNormales(10);
       }
        else if(tab[1][0]==null){
         tab[1][0] = new TanquesNormales(10);
       }
        else if(tab[1][1]==null){
         tab[1][1] = new TanquesNormales(10);
       }
        
      }
        if(numT == 2){
          
          if(tab[0][0]==null){
         tab[0][0] = new TanquesAlien(20);
        }
       else if(tab[0][1]==null){
         tab[0][1] = new TanquesAlien(20);
       }
        else if(tab[1][0]==null){
         tab[1][0] = new TanquesAlien(20);
       }
        else if(tab[1][1]==null){
         tab[1][1] = new TanquesAlien(20);
       }
        }
      }
         for(int t = 0; t<tab.length; t++){
           for(int y =0; y<tab.length; y++){
             if(tab[t][y]== null){
               tab[t][y] = new TanquesVacios(0);
             }
           }
           }
         

      break;
        //Tablero-------------------------
      //Terminar ciclo al finalizar el tablero
}//Ciclo infinito
          return tab;
    }//Juego

      
       }