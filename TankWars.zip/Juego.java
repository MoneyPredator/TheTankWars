import java.util.Scanner; 
import java.io.PrintWriter;
import java.io.File;
public class Juego{
  public static void main(String[] args) {
    Juego.mostrarMenu();
  }
  
  public static void mostrarMenu(){
     System.out.println("\n\n77777777777777777777777777 Welcome to Tanks-Atack 77777777777777777777777777777\n\n");
    System.out.println("Aqui estan tus tanques listos para la guerra"+"\n");
    Tanque theTab[][] = Tablero.board();
        System.out.print("||"+theTab[0][0]+"|"+theTab[0][1]+"||"+"\n"+"||"+theTab[1][0]+"|"+theTab[1][1]+"||"+"\n");
    
    
    Scanner scan = new Scanner(System.in);
      //Salida------------
      //Inicia el juego (Aqui van los poderes del jugador pa)
      System.out.println("\nIngrese el numero '0' para salir del juego."+"\n");
      System.out.println("Ingrese el numero '1' para disparar hacia un tanque."+"\n");
      System.out.println("Ingrese el numero '2' para activar bomba atomica."+"\n");
      System.out.println("Ingrese el numero '3' para activar el tanque mutante."+"\n");
      System.out.println("Ingrese el numero '4' para ver la frase de la Abuela ."+"\n");
      System.out.println("Ingrese el numero '5' para ver la cantidad de disparos realizados."+"\n");
      System.out.println("Ingrese el numero '6' para ver la cantidad de sangre"+"\n");
    System.out.println("Ingrese el numero '7' para guardar la cantidad de sangre en un archivo"+"\n");
    int shootCount=0;
    int dsangre=0;
      while(true){
        int pick = scan.nextInt();

      if(pick == 0){
               System.out.println("Vuelve pronto bb.");
               break;
              }
              
      // opcion 1 -----------------------------
      else if(pick == 1){

        System.out.println("Elige a que posicion quieres disparar");
        System.out.println("Presiona 1 para disparar arriba a la izquierda");
        System.out.println("Presiona 2 para disparar arriba a la derecha");
        System.out.println("Presiona 3 para disparar abajo a la izquierda");
        System.out.println("Presiona 4 para disparar abajo a la derecha");
        int shot = scan.nextInt();

        
        if(shot == 1){
          if(theTab[0][0].getSalud()>0){
            theTab[0][0].shootBullet();
            shootCount++;
            dsangre = dsangre+5;
            if(theTab[0][0].getSalud()<=0){
              theTab[0][0] = new TanquesVacios(0);
            }
            if(theTab[0][0].getSalud()<=0 &&theTab[0][1].getSalud()<=0 && theTab[1][0].getSalud()<=0 &&theTab[1][1].getSalud()<=0){
              System.out.println("Has ganado el juego");
              break;
            }
            System.out.print("||"+theTab[0][0]+"|"+theTab[0][1]+"||"+"\n"+"||"+theTab[1][0]+"|"+theTab[1][1]+"||"+"\n");
            System.out.println("Vuelve a mirar el menu para realizar alguna otra opcion");
          }
          else{
            System.out.println("Opcion no valida");
          }
          
        }
          
        else if(shot == 2){
          if(theTab[0][1].getSalud()>0){
            theTab[0][1].shootBullet();
            shootCount++;
            dsangre = dsangre+5;
            if(theTab[0][1].getSalud()<=0){
              theTab[0][1] = new TanquesVacios(0);
            }
            if(theTab[0][0].getSalud()<=0 &&theTab[0][1].getSalud()<=0 && theTab[1][0].getSalud()<=0 &&theTab[1][1].getSalud()<=0){
              System.out.println("Has ganado el juego");
              break;
            }
            System.out.print("||"+theTab[0][0]+"|"+theTab[0][1]+"||"+"\n"+"||"+theTab[1][0]+"|"+theTab[1][1]+"||"+"\n");
            System.out.println("Vuelve a mirar el menu para realizar alguna otra opcion");
          }
          else{
            System.out.println("Opcion no valida");
          }
          
        }
        
        else if(shot == 3){
          if(theTab[1][0].getSalud()>0){
            theTab[1][0].shootBullet();
            shootCount++;
            dsangre = dsangre+5;
            if(theTab[1][0].getSalud()<=0){
              theTab[1][0] = new TanquesVacios(0);
            }
            if(theTab[0][0].getSalud()<=0 &&theTab[0][1].getSalud()<=0 && theTab[1][0].getSalud()<=0 &&theTab[1][1].getSalud()<=0){
              System.out.println("Has ganado el juego");
              break;
            }
            System.out.print("||"+theTab[0][0]+"|"+theTab[0][1]+"||"+"\n"+"||"+theTab[1][0]+"|"+theTab[1][1]+"||"+"\n");
            System.out.println("Vuelve a mirar el menu para realizar alguna otra opcion");
          }
          else{
            System.out.println("Opcion no valida");
          }
        }
        
        else if(shot == 4){
          if(theTab[1][1].getSalud()>0){
            theTab[1][1].shootBullet();
            shootCount++;
            dsangre = dsangre+5;
            if(theTab[1][1].getSalud()<=0){
              theTab[1][1] = new TanquesVacios(0);
            }
            if(theTab[0][0].getSalud()<=0 &&theTab[0][1].getSalud()<=0 && theTab[1][0].getSalud()<=0 &&theTab[1][1].getSalud()<=0){
              System.out.println("Has ganado el juego");
              break;
            }
            System.out.print("||"+theTab[0][0]+"|"+theTab[0][1]+"||"+"\n"+"||"+theTab[1][0]+"|"+theTab[1][1]+"||"+"\n");
            System.out.println("Vuelve a mirar el menu para realizar alguna otra opcion");
          }
           
          else{
            System.out.println("Opcion no valida");
          }
        }
        
        else{
          System.out.println("Esa opcion no es valida mi bro");
          System.out.println("Vuelve a mirar el menu para realizar alguna otra opcion");
        }
}//Fin opcion 1
        
        // opcion 2 -----------------------------
              else if(pick == 2){
                int irochima = (int)((Math.random()*4)+1);
                  System.out.println("\nHaz activado la bomba nuclear");
                if(irochima == 1){
                  if(theTab[0][0].getSalud() >0){
                  dsangre = dsangre + theTab[0][0].getSalud();
                  theTab[0][0].atomicBomb();
                  theTab[0][0] = new TanquesVacios(0);
                  if(theTab[0][0].getSalud()<=0 &&theTab[0][1].getSalud()<=0 && theTab[1][0].getSalud()<=0 &&theTab[1][1].getSalud()<=0){
                    System.out.println("Has ganado el juego");
                    break;
                  }
                  System.out.print("||"+theTab[0][0]+"|"+theTab[0][1]+"||"+"\n"+"||"+theTab[1][0]+"|"+theTab[1][1]+"||"+"\n");
        System.out.println("Vuelve a mirar el menu para realizar alguna otra opcion");
              }
            }
            if(irochima == 2){
              if(theTab[0][1].getSalud() >0){
              dsangre = dsangre + theTab[0][1].getSalud();
              theTab[0][1].atomicBomb();
              theTab[0][1] = new TanquesVacios(0);
              if(theTab[0][0].getSalud()<=0 &&theTab[0][1].getSalud()<=0 && theTab[1][0].getSalud()<=0 &&theTab[1][1].getSalud()<=0){
                System.out.println("Has ganado el juego");
                break;
              }
              System.out.print("||"+theTab[0][0]+"|"+theTab[0][1]+"||"+"\n"+"||"+theTab[1][0]+"|"+theTab[1][1]+"||"+"\n");
    System.out.println("Vuelve a mirar el menu para realizar alguna otra opcion");
          }
        }
        if(irochima == 3){
          if(theTab[1][0].getSalud() >0){
          dsangre = dsangre + theTab[1][0].getSalud();
          theTab[1][0].atomicBomb();
          theTab[1][0] = new TanquesVacios(0);
          if(theTab[0][0].getSalud()<=0 &&theTab[0][1].getSalud()<=0 && theTab[1][0].getSalud()<=0 &&theTab[1][1].getSalud()<=0){
            System.out.println("Has ganado el juego");
            break;
          }
          System.out.print("||"+theTab[0][0]+"|"+theTab[0][1]+"||"+"\n"+"||"+theTab[1][0]+"|"+theTab[1][1]+"||"+"\n");
System.out.println("Vuelve a mirar el menu para realizar alguna otra opcion");
      }
    }
    if(irochima == 4){
      if(theTab[1][1].getSalud() >0){
      dsangre = dsangre + theTab[0][0].getSalud();
      theTab[1][1].atomicBomb();
      theTab[1][1] = new TanquesVacios(0);
      if(theTab[0][0].getSalud()<=0 &&theTab[0][1].getSalud()<=0 && theTab[1][0].getSalud()<=0 &&theTab[1][1].getSalud()<=0){
        System.out.println("Has ganado el juego");
        break;
      }
System.out.print("||"+theTab[0][0]+"|"+theTab[0][1]+"||"+"\n"+"||"+theTab[1][0]+"|"+theTab[1][1]+"||"+"\n");
System.out.println("Vuelve a mirar el menu para realizar alguna otra opcion");
  }
  else{
    System.out.println("OOOPS!!! La bomba ha sido robada por los nazis");
    System.out.print("||"+theTab[0][0]+"|"+theTab[0][1]+"||"+"\n"+"||"+theTab[1][0]+"|"+theTab[1][1]+"||"+"\n");
  }
}
              }

        // opcion 3 -----------------------------==3

              else if(pick == 3){
                 System.out.println("\nHaz mutado un tanque");
                int num = 0;
                int w = 0;
                int x = 0;
                int y = 0;
                int z = 0;

                
                if(theTab[0][0].getSalud() > 0){
                  w = theTab[0][0].getSalud();
                  num++;
                }
                if(theTab[0][1].getSalud()> 0){
                  x = theTab[0][1].getSalud();
                  num++;
                }
                if(theTab[1][0].getSalud()> 0){
                  y = theTab[1][0].getSalud();
                  num++;
                }
                if(theTab[1][1].getSalud()> 0){
                  z = theTab[1][1].getSalud();
                  num++;
                }

                if(num == 1){
                    theTab[0][0].activateMutant();
                    System.out.print("||"+theTab[0][0]+"|"+theTab[0][1]+"||"+"\n"+"||"+theTab[1][0]+"|"+theTab[1][1]+"||"+"\n");
                }
                else if(num == 2){
                  if(w<=x){
                    theTab[0][0].activateMutant();
                    System.out.print("||"+theTab[0][0]+"|"+theTab[0][1]+"||"+"\n"+"||"+theTab[1][0]+"|"+theTab[1][1]+"||"+"\n");
                  }
                  else if(x<=w){
                    theTab[0][1].activateMutant();
                    System.out.print("||"+theTab[0][0]+"|"+theTab[0][1]+"||"+"\n"+"||"+theTab[1][0]+"|"+theTab[1][1]+"||"+"\n");
                  }
              }

              else if(num == 3){
                if(w<=x && w<=y){
                  theTab[0][0].activateMutant();
                  System.out.print("||"+theTab[0][0]+"|"+theTab[0][1]+"||"+"\n"+"||"+theTab[1][0]+"|"+theTab[1][1]+"||"+"\n");
                }
                else if(x<=w && x<=y){
                  theTab[0][1].activateMutant();
                  System.out.print("||"+theTab[0][0]+"|"+theTab[0][1]+"||"+"\n"+"||"+theTab[1][0]+"|"+theTab[1][1]+"||"+"\n");
                }
                else if(y<=w && y<=x){
                  theTab[1][0].activateMutant();
                  System.out.print("||"+theTab[0][0]+"|"+theTab[0][1]+"||"+"\n"+"||"+theTab[1][0]+"|"+theTab[1][1]+"||"+"\n");
                }
            }
            else if(num == 4){
              if(w<=x && w<=y && w<=z){
                theTab[0][0].activateMutant();
                System.out.print("||"+theTab[0][0]+"|"+theTab[0][1]+"||"+"\n"+"||"+theTab[1][0]+"|"+theTab[1][1]+"||"+"\n");
              }
              else if(x<=w && x<=y && x<=z){
                theTab[0][1].activateMutant();
                System.out.print("||"+theTab[0][0]+"|"+theTab[0][1]+"||"+"\n"+"||"+theTab[1][0]+"|"+theTab[1][1]+"||"+"\n");
              }
              else if(y<=w && y<=x && y<=z){
                theTab[1][0].activateMutant();
                System.out.print("||"+theTab[0][0]+"|"+theTab[0][1]+"||"+"\n"+"||"+theTab[1][0]+"|"+theTab[1][1]+"||"+"\n");
              }
              else if(z<=w && z<=x && z<=y){
                theTab[1][1].activateMutant();
                System.out.print("||"+theTab[0][0]+"|"+theTab[0][1]+"||"+"\n"+"||"+theTab[1][0]+"|"+theTab[1][1]+"||"+"\n");
              }
          }

              }//Opcion 3 final


        // opcion 4 -----------------------------
              else if(pick == 4){
               System.out.println(Tanque.fraseAbuela());              }
        // opcion 5 -----------------------------
              else if(pick == 5){
                System.out.println(shootCount +" disparos realizados");
              }
        // opcion 6 -----------------------------
              else if(pick == 6){
                System.out.println(Tanque.searchBlood()+" litros de sangre derramada");
                }

        // opcion 7 -----------------------------
              else if(pick == 7){
                System.out.println("\nArchivo creado");
                 File file = new File("Blood");
                PrintWriter output = null;
                try{
                  output = new PrintWriter(file);
                  output.println(dsangre+" litros de sangre derramada");
                }catch(Exception e){                  
                System.out.println(e.getMessage());
                }finally{
                  if(output !=null){
                    output.close();
                  }
                }
                }
      }

  }
      
  //El inicio el juego
}