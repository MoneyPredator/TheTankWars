class TanquesNormales extends Tanque{
  
  public TanquesNormales(int salud){
    super(10);
  }
    @Override
  public String toString(){
    return "TN-"+ this.getSalud();
  }
}