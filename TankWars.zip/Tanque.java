class Tanque{
  private int salud;

  public Tanque(int salud){
    this.salud = salud;
  }
  public void setSalud(int s){
    this.salud = s;
  }
   public int getSalud(){
     return this.salud;
   }
//Metodo para disparar la bala 
    public void shootBullet(){
    this.salud = this.salud-5;
  }
//Metodo para eliminar un tanque random
  public void atomicBomb(){
    this.salud = this.salud-this.salud;
  }

  //Metodo para duplicar la vida 
  public void activateMutant(){
    this.salud = this.salud*2;
  }

  //Metodo de la frase random de la abuela 
  public static String fraseAbuela(){
    String frase = "En mis tiempos estos papanatas aguantaban mas balasos";
    return frase;
  }

  //Contado de balas
  public static int shootCounter(){
    int contador = 0;
    return contador;
  }

  //Total de vida 
  public static int searchBlood(){
    int sangre = 0;
    return sangre;
  }
  
  
}