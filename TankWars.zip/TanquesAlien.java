class TanquesAlien extends Tanque{
  
  public TanquesAlien(int salud){
    super(20);
  }
    @Override
  public String toString(){
    return "TA-"+ this.getSalud();
  }
}