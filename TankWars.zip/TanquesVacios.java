class TanquesVacios extends Tanque{
  public TanquesVacios(int salud){
    super(0);
  }
    @Override
  public String toString(){
    return "     ";
  }
}